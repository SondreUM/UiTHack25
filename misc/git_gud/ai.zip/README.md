# My new AI project

This project is gonna be Awe5ome
